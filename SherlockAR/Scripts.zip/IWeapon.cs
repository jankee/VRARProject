﻿using System.Collections;
using System.Collections.Generic;

public interface IWeapon
{
    List<BaseStat> Stats { get; set; }

    int CurrentDamage { get; set; }

    //CharacterStats CharacterStats { get; set; }

    void PerformAttack(int damage);

    void PerformSpecialAttack();
}